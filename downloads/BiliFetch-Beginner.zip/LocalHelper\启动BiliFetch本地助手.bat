@echo off
setlocal
set "HELPER_DIR=%~dp0"
set "HELPER_PS1=%HELPER_DIR%BiliFetch-LocalHelper.ps1"
title BiliFetch Local Helper
echo ========================================
echo BiliFetch Local Helper
echo ========================================
echo.
echo Helper folder: %HELPER_DIR%
echo.
if not exist "%HELPER_PS1%" (
  echo Missing BiliFetch-LocalHelper.ps1.
  echo Please unzip the whole helper folder first.
  echo Do not run this file inside the zip preview.
  echo.
  pause
  exit /b 1
)

where powershell >nul 2>nul
if errorlevel 1 (
  echo Windows PowerShell was not found.
  echo Please send this message to the author.
  echo.
  pause
  exit /b 1
)

echo Keep this window open while downloading.
echo The browser script will use this helper automatically.
echo If startup fails, run the diagnosis bat file in this folder.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%HELPER_PS1%"
set "EXIT_CODE=%ERRORLEVEL%"
echo.
echo Local helper stopped. Exit code: %EXIT_CODE%
echo If you did not close it, run the diagnosis bat file and send the log.
pause
endlocal
