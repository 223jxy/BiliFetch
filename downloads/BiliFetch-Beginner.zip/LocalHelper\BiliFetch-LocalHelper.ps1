param(
  [switch]$RunJob,
  [string]$JobFile,
  [switch]$SelfTest
)

$ErrorActionPreference = "Stop"
$Version = "1.1.0"
$Port = 18991
$DefaultDownloadDir = Join-Path ([Environment]::GetFolderPath("UserProfile")) "Downloads\BiliFetch"
$DownloadDir = if ($env:BILIFETCH_DOWNLOAD_DIR) { [IO.Path]::GetFullPath($env:BILIFETCH_DOWNLOAD_DIR) } else { $DefaultDownloadDir }
$LogDir = Join-Path $DownloadDir "_logs"

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Ensure-Dirs {
  New-Item -ItemType Directory -Path $DownloadDir -Force | Out-Null
  New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}

function Write-HelperLog {
  param([string]$Path, [string]$Message)
  $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Message
  Add-Content -LiteralPath $Path -Encoding UTF8 -Value $line
}

function ConvertTo-JsonText {
  param($Object)
  return ($Object | ConvertTo-Json -Depth 8 -Compress)
}

function Safe-FileName {
  param([string]$Name)
  $leaf = [IO.Path]::GetFileName($Name)
  if ([string]::IsNullOrWhiteSpace($leaf)) {
    $leaf = "bilifetch-file"
  }
  foreach ($char in [IO.Path]::GetInvalidFileNameChars()) {
    $leaf = $leaf.Replace([string]$char, "_")
  }
  if ($leaf.Length -gt 160) {
    $ext = [IO.Path]::GetExtension($leaf)
    $stem = [IO.Path]::GetFileNameWithoutExtension($leaf)
    $leaf = $stem.Substring(0, [Math]::Min(140, $stem.Length)) + $ext
  }
  return $leaf
}

function Get-TargetPath {
  param([string]$Name)
  return (Join-Path $DownloadDir (Safe-FileName $Name))
}

function Get-FfmpegPath {
  $local = Join-Path $PSScriptRoot "ffmpeg.exe"
  if (Test-Path -LiteralPath $local) {
    return $local
  }
  $command = Get-Command "ffmpeg.exe" -ErrorAction SilentlyContinue
  if ($command) {
    return $command.Source
  }
  return $null
}

function Get-FfmpegStatus {
  $path = Get-FfmpegPath
  if (!$path) {
    return @{
      ok = $false
      found = $false
      path = ""
      version = ""
      message = "ffmpeg.exe not found."
      fix = @(
        "Put ffmpeg.exe in the same folder as this helper.",
        "Or install ffmpeg and add it to PATH.",
        "Then restart this helper window."
      )
    }
  }

  try {
    $output = & $path -version 2>&1
    if ($LASTEXITCODE -ne 0) {
      throw "ffmpeg -version exited with code $LASTEXITCODE"
    }
    $firstLine = ($output | Select-Object -First 1)
    return @{
      ok = $true
      found = $true
      path = $path
      version = [string]$firstLine
      message = "ffmpeg is ready."
      fix = @()
    }
  } catch {
    return @{
      ok = $false
      found = $true
      path = $path
      version = ""
      message = "ffmpeg.exe was found but cannot run: $($_.Exception.Message)"
      fix = @(
        "Replace ffmpeg.exe with a working Windows build.",
        "Or reinstall ffmpeg and add it to PATH.",
        "Then restart this helper window."
      )
    }
  }
}

function New-Downloader {
  param($Headers)
  $client = New-Object System.Net.WebClient
  $client.Headers.Add("User-Agent", "Mozilla/5.0 BiliFetch-LocalHelper/$Version")
  if ($Headers) {
    foreach ($property in $Headers.PSObject.Properties) {
      if ($property.Name -and $property.Value) {
        $client.Headers.Remove($property.Name)
        $client.Headers.Add($property.Name, [string]$property.Value)
      }
    }
  }
  return $client
}

function Download-One {
  param($Item, $Headers, [string]$LogFile)

  $target = Get-TargetPath $Item.filename
  if ((Test-Path -LiteralPath $target) -and ((Get-Item -LiteralPath $target).Length -gt 0)) {
    Write-HelperLog $LogFile "File already exists, skip download: $target"
    return $target
  }

  $urls = @($Item.urls) | Where-Object { $_ }
  if (!$urls.Count) {
    throw "No download URL: $($Item.filename)"
  }

  $lastError = $null
  for ($index = 0; $index -lt $urls.Count; $index += 1) {
    $url = [string]$urls[$index]
    $tmp = "$target.part"
    Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    $client = $null
    try {
      Write-HelperLog $LogFile "Start downloading $($Item.role): $($Item.filename), URL $($index + 1)/$($urls.Count)"
      $client = New-Downloader $Headers
      $client.DownloadFile($url, $tmp)
      if (!(Test-Path -LiteralPath $tmp) -or ((Get-Item -LiteralPath $tmp).Length -le 0)) {
        throw "Downloaded file is empty"
      }
      Move-Item -LiteralPath $tmp -Destination $target -Force
      Write-HelperLog $LogFile "Download completed: $target"
      return $target
    } catch {
      $lastError = $_.Exception.Message
      Write-HelperLog $LogFile "Download failed, try next URL: $lastError"
      Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    } finally {
      if ($client) {
        $client.Dispose()
      }
    }
  }

  throw "Download failed: $($Item.filename), last error: $lastError"
}

function Quote-ProcessArg {
  param([string]$Value)
  return '"' + ($Value -replace '"', '\"') + '"'
}

function Invoke-FfmpegMerge {
  param([string]$VideoPath, [string]$AudioPath, [string]$OutputPath, [string]$LogFile)

  $ffmpegStatus = Get-FfmpegStatus
  if (!$ffmpegStatus.ok) {
    throw "$($ffmpegStatus.message) Fix: $($ffmpegStatus.fix -join ' ')"
  }
  $ffmpeg = $ffmpegStatus.path

  $arguments = @(
    "-y",
    "-i", (Quote-ProcessArg $VideoPath),
    "-i", (Quote-ProcessArg $AudioPath),
    "-c", "copy",
    (Quote-ProcessArg $OutputPath)
  ) -join " "

  Write-HelperLog $LogFile "Start merging: $OutputPath"
  $process = Start-Process -FilePath $ffmpeg -ArgumentList $arguments -NoNewWindow -Wait -PassThru
  if ($process.ExitCode -ne 0) {
    throw "ffmpeg merge failed, exit code: $($process.ExitCode)"
  }
  Write-HelperLog $LogFile "Merge completed: $OutputPath"
}

function Invoke-BiliFetchJob {
  param([string]$Path)

  Ensure-Dirs
  if (!(Test-Path -LiteralPath $Path)) {
    throw "Job file not found: $Path"
  }

  $job = Get-Content -LiteralPath $Path -Encoding UTF8 -Raw | ConvertFrom-Json
  $logFile = if ($job.logFile) { [string]$job.logFile } else { Join-Path $LogDir "bilifetch-job.log" }
  Write-HelperLog $logFile "Job started: $($job.title)"
  Write-HelperLog $logFile "Source page: $($job.sourceUrl)"

  try {
    if ($job.kind -eq "download_files") {
      foreach ($item in @($job.items)) {
        Download-One $item $job.headers $logFile | Out-Null
      }
      Write-HelperLog $logFile "Job completed: complete video downloaded."
      return
    }

    if ($job.kind -eq "merge_av") {
      $videoPath = Download-One $job.video $job.headers $logFile
      $audioPath = Download-One $job.audio $job.headers $logFile
      $outputPath = Get-TargetPath $job.output.filename
      Invoke-FfmpegMerge $videoPath $audioPath $outputPath $logFile

      if ($job.deleteTemp) {
        Remove-Item -LiteralPath $videoPath -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $audioPath -Force -ErrorAction SilentlyContinue
        Write-HelperLog $logFile "Temporary audio/video files deleted."
      }
      Write-HelperLog $logFile "Job completed: $outputPath"
      return
    }

    throw "Unknown job kind: $($job.kind)"
  } catch {
    Write-HelperLog $logFile "Job failed: $($_.Exception.Message)"
    throw
  }
}

function Send-HttpResponse {
  param($Stream, [int]$Status, $Body, [string]$ContentType = "application/json; charset=utf-8")

  $statusText = @{
    200 = "OK"
    202 = "Accepted"
    204 = "No Content"
    400 = "Bad Request"
    404 = "Not Found"
    500 = "Internal Server Error"
  }[$Status]
  if (!$statusText) {
    $statusText = "OK"
  }

  if ($ContentType -like "application/json*" -and !($Body -is [string])) {
    $text = ConvertTo-JsonText $Body
  } else {
    $text = [string]$Body
  }
  $bytes = [Text.Encoding]::UTF8.GetBytes($text)
  $headers = @(
    "HTTP/1.1 $Status $statusText",
    "Content-Type: $ContentType",
    "Access-Control-Allow-Origin: *",
    "Access-Control-Allow-Methods: GET, POST, OPTIONS",
    "Access-Control-Allow-Headers: Content-Type",
    "Content-Length: $($bytes.Length)",
    "Connection: close",
    "",
    ""
  ) -join "`r`n"

  $headerBytes = [Text.Encoding]::ASCII.GetBytes($headers)
  $Stream.Write($headerBytes, 0, $headerBytes.Length)
  if ($bytes.Length -gt 0) {
    $Stream.Write($bytes, 0, $bytes.Length)
  }
}

function Read-HttpRequest {
  param($Client)

  $stream = $Client.GetStream()
  $reader = New-Object IO.StreamReader($stream, [Text.Encoding]::UTF8, $false, 4096, $true)
  $requestLine = $reader.ReadLine()
  if ([string]::IsNullOrWhiteSpace($requestLine)) {
    return $null
  }

  $parts = $requestLine.Split(" ")
  $headers = @{}
  while ($true) {
    $line = $reader.ReadLine()
    if ($null -eq $line -or $line -eq "") {
      break
    }
    $colon = $line.IndexOf(":")
    if ($colon -gt 0) {
      $name = $line.Substring(0, $colon).Trim().ToLowerInvariant()
      $value = $line.Substring($colon + 1).Trim()
      $headers[$name] = $value
    }
  }

  $body = ""
  $length = 0
  if ($headers.ContainsKey("content-length")) {
    [int]::TryParse($headers["content-length"], [ref]$length) | Out-Null
  }
  if ($length -gt 0) {
    $buffer = New-Object char[] $length
    $read = 0
    while ($read -lt $length) {
      $count = $reader.Read($buffer, $read, $length - $read)
      if ($count -le 0) {
        break
      }
      $read += $count
    }
    if ($read -gt 0) {
      $body = -join $buffer[0..($read - 1)]
    }
  }

  return @{
    Method = $parts[0]
    Path = $parts[1]
    Headers = $headers
    Body = $body
    Stream = $stream
  }
}

function Get-RoutePath {
  param([string]$Path)
  $index = $Path.IndexOf("?")
  if ($index -lt 0) {
    return $Path
  }
  return $Path.Substring(0, $index)
}

function Get-QueryValue {
  param([string]$Path, [string]$Name)
  $index = $Path.IndexOf("?")
  if ($index -lt 0) {
    return $null
  }

  $query = $Path.Substring($index + 1)
  foreach ($pair in $query.Split("&")) {
    if ([string]::IsNullOrWhiteSpace($pair)) {
      continue
    }
    $equals = $pair.IndexOf("=")
    if ($equals -ge 0) {
      $key = $pair.Substring(0, $equals)
      $value = $pair.Substring($equals + 1)
    } else {
      $key = $pair
      $value = ""
    }
    $key = [Uri]::UnescapeDataString($key.Replace("+", " "))
    if ($key -eq $Name) {
      return [Uri]::UnescapeDataString($value.Replace("+", " "))
    }
  }
  return $null
}

function Get-JobPathById {
  param([string]$JobId)
  if ([string]::IsNullOrWhiteSpace($JobId)) {
    return $null
  }
  $safe = [IO.Path]::GetFileName($JobId)
  $path = Join-Path $LogDir "$safe.job.json"
  if (Test-Path -LiteralPath $path) {
    return $path
  }
  return $null
}

function Get-JobSummary {
  param([string]$JobPath)

  $job = Get-Content -LiteralPath $JobPath -Encoding UTF8 -Raw | ConvertFrom-Json
  $jobId = if ($job.jobId) { [string]$job.jobId } else { [IO.Path]::GetFileNameWithoutExtension([IO.Path]::GetFileNameWithoutExtension($JobPath)) }
  $logFile = if ($job.logFile) { [string]$job.logFile } else { Join-Path $LogDir "$jobId.log.txt" }
  $lines = @()
  if (Test-Path -LiteralPath $logFile) {
    $lines = @(Get-Content -LiteralPath $logFile -Encoding UTF8 -Tail 80 -ErrorAction SilentlyContinue | ForEach-Object { [string]$_ })
  }

  $status = "queued"
  if ($lines.Count -gt 0) {
    $status = "running"
  }
  if ($lines -match "Job completed") {
    $status = "completed"
  }
  if ($lines -match "Job failed") {
    $status = "failed"
  }

  $timeSource = if (Test-Path -LiteralPath $logFile) { Get-Item -LiteralPath $logFile } else { Get-Item -LiteralPath $JobPath }
  return [pscustomobject]@{
    id = $jobId
    status = $status
    kind = $job.kind
    title = $job.title
    sourceUrl = $job.sourceUrl
    output = if ($job.output) { $job.output.filename } else { "" }
    downloadDir = $DownloadDir
    logFile = $logFile
    updatedAt = $timeSource.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")
    lines = $lines
  }
}

function Get-RecentJobs {
  Ensure-Dirs
  return @(Get-ChildItem -LiteralPath $LogDir -Filter "*.job.json" -ErrorAction SilentlyContinue |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 30 |
    ForEach-Object { Get-JobSummary $_.FullName })
}

function Get-ProgressHtml {
@'
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BiliFetch Local Helper</title>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; color: #1f2937; background: #f5f7fb; font: 14px/1.55 Arial, sans-serif; }
    main { width: min(980px, calc(100vw - 28px)); margin: 0 auto; padding: 24px 0 40px; }
    h1 { margin: 0 0 6px; font-size: 26px; }
    .muted { color: #64748b; }
    .top { display: flex; justify-content: space-between; gap: 12px; align-items: center; margin-bottom: 16px; }
    button { min-height: 34px; padding: 0 12px; border: 1px solid #cbd5e1; border-radius: 6px; background: #fff; cursor: pointer; }
    .jobs { display: grid; gap: 12px; }
    .job { background: #fff; border: 1px solid #d8dee9; border-radius: 8px; overflow: hidden; }
    .job-head { display: grid; grid-template-columns: 1fr auto; gap: 12px; padding: 12px; border-bottom: 1px solid #edf2f7; }
    .title { margin: 0; font-size: 16px; font-weight: 700; word-break: break-word; }
    .badge { align-self: start; border-radius: 999px; padding: 3px 10px; font-size: 12px; background: #e2e8f0; }
    .completed { background: #dcfce7; color: #166534; }
    .failed { background: #fee2e2; color: #991b1b; }
    .running { background: #dbeafe; color: #1d4ed8; }
    .queued { background: #fef3c7; color: #92400e; }
    .meta { padding: 0 12px 10px; color: #64748b; font-size: 12px; }
    pre { margin: 0; padding: 12px; max-height: 260px; overflow: auto; background: #0f172a; color: #e2e8f0; white-space: pre-wrap; word-break: break-word; }
    .empty { padding: 18px; background: #fff; border: 1px solid #d8dee9; border-radius: 8px; }
    .status-card { display: grid; gap: 6px; margin: 0 0 14px; padding: 12px; background: #fff; border: 1px solid #d8dee9; border-radius: 8px; }
    .status-title { margin: 0; font-weight: 700; color: #0f172a; }
    .status-ok { color: #166534; font-weight: 700; }
    .status-warn { color: #92400e; font-weight: 700; }
  </style>
</head>
<body>
  <main>
    <div class="top">
      <div>
        <h1>BiliFetch Local Helper</h1>
        <div class="muted">Keep the helper window open. This page refreshes every 2 seconds.</div>
      </div>
      <button onclick="loadJobs()">Refresh</button>
    </div>
    <div id="status" class="status-card">
      <p class="status-title">Helper status</p>
      <div class="muted">Loading...</div>
    </div>
    <div id="jobs" class="jobs"></div>
  </main>
  <script>
    function escapeHtml(value) {
      return String(value || '').replace(/[&<>"']/g, function (char) {
        return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
      });
    }
    async function loadJobs() {
      const status = document.getElementById('status');
      const root = document.getElementById('jobs');
      try {
        const data = await fetch('/jobs?ts=' + Date.now()).then(function (response) { return response.json(); });
        const ffmpegOk = data.ffmpegStatus && data.ffmpegStatus.ok;
        status.innerHTML = '<p class="status-title">Helper is running</p>' +
          '<div><span class="status-ok">Online</span> | Download folder: ' + escapeHtml(data.downloadDir) + '</div>' +
          '<div>ffmpeg: <span class="' + (ffmpegOk ? 'status-ok' : 'status-warn') + '">' + escapeHtml(data.ffmpegStatus && data.ffmpegStatus.message) + '</span></div>' +
          '<div class="muted">Next step: return to the Bilibili page, click More > Check Helper, then click Start.</div>';
        if (!data.jobs.length) {
          root.innerHTML = '<div class="empty">No tasks yet. Keep this window open, then start a download from the Bilibili page.</div>';
          return;
        }
        root.innerHTML = data.jobs.map(function (job) {
          const lines = (job.lines || []).join('\n');
          return '<section class="job">' +
            '<div class="job-head"><p class="title">' + escapeHtml(job.title || job.id) + '</p><span class="badge ' + escapeHtml(job.status) + '">' + escapeHtml(job.status) + '</span></div>' +
            '<div class="meta">ID: ' + escapeHtml(job.id) + ' | Updated: ' + escapeHtml(job.updatedAt) + ' | Output: ' + escapeHtml(job.output || '-') + '</div>' +
            '<pre>' + escapeHtml(lines || 'Waiting for log...') + '</pre>' +
          '</section>';
        }).join('');
      } catch (error) {
        status.textContent = 'Cannot load tasks: ' + error.message;
      }
    }
    loadJobs();
    setInterval(loadJobs, 2000);
  </script>
</body>
</html>
'@
}

function Start-HelperServer {
  Ensure-Dirs
  $listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Parse("127.0.0.1"), $Port)
  $listener.Start()
  Write-Host "BiliFetch Local Helper is running."
  Write-Host "Listen URL: http://127.0.0.1:$Port"
  Write-Host "Progress page: http://127.0.0.1:$Port/"
  Write-Host "Download folder: $DownloadDir"
  $ffmpegStatus = Get-FfmpegStatus
  Write-Host "ffmpeg: $($ffmpegStatus.message)"
  if (!$ffmpegStatus.ok) {
    foreach ($fix in $ffmpegStatus.fix) {
      Write-Host "  - $fix"
    }
  }
  Write-Host "Keep this window open. If it is closed, the browser script tries browser-side merging."
  Write-Host ""

  while ($true) {
    $client = $listener.AcceptTcpClient()
    try {
      $request = Read-HttpRequest $client
      if (!$request) {
        continue
      }

      $routePath = Get-RoutePath $request.Path
      if ($request.Method -eq "OPTIONS") {
        Send-HttpResponse $request.Stream 204 ""
      } elseif ($request.Method -eq "GET" -and ($routePath -eq "/" -or $routePath -eq "/index.html")) {
        Send-HttpResponse $request.Stream 200 (Get-ProgressHtml) "text/html; charset=utf-8"
      } elseif ($request.Method -eq "GET" -and $routePath -eq "/jobs") {
        $ffmpegStatus = Get-FfmpegStatus
        Send-HttpResponse $request.Stream 200 @{
          ok = $true
          version = $Version
          downloadDir = $DownloadDir
          ffmpegStatus = $ffmpegStatus
          jobs = @(Get-RecentJobs)
        }
      } elseif ($request.Method -eq "GET" -and $routePath -eq "/job") {
        $jobId = Get-QueryValue $request.Path "id"
        $jobPath = Get-JobPathById $jobId
        if ($jobPath) {
          Send-HttpResponse $request.Stream 200 @{
            ok = $true
            job = (Get-JobSummary $jobPath)
          }
        } else {
          Send-HttpResponse $request.Stream 404 @{ ok = $false; error = "Job not found" }
        }
      } elseif ($request.Method -eq "GET" -and $routePath -eq "/status") {
        $ffmpegStatus = Get-FfmpegStatus
        Send-HttpResponse $request.Stream 200 @{
          ok = $true
          name = "BiliFetch Local Helper"
          version = $Version
          downloadDir = $DownloadDir
          ffmpeg = $ffmpegStatus.ok
          ffmpegStatus = $ffmpegStatus
        }
      } elseif ($request.Method -eq "POST" -and $routePath -eq "/task") {
        $payload = $request.Body | ConvertFrom-Json
        $jobId = Get-Date -Format "yyyyMMdd-HHmmss-fff"
        $jobPath = Join-Path $LogDir "$jobId.job.json"
        $logFile = Join-Path $LogDir "$jobId.log.txt"
        $payload | Add-Member -NotePropertyName jobId -NotePropertyValue $jobId -Force
        $payload | Add-Member -NotePropertyName logFile -NotePropertyValue $logFile -Force
        ConvertTo-JsonText $payload | Set-Content -LiteralPath $jobPath -Encoding UTF8
        Write-HelperLog $logFile "Job queued: $($payload.title)"

        $powershell = Join-Path $PSHOME "powershell.exe"
        if (!(Test-Path -LiteralPath $powershell)) {
          $powershell = "powershell.exe"
        }
        $args = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`"", "-RunJob", "-JobFile", "`"$jobPath`"")
        Start-Process -FilePath $powershell -ArgumentList $args -WindowStyle Hidden | Out-Null

        Send-HttpResponse $request.Stream 202 @{
          ok = $true
          accepted = $true
          jobId = $jobId
          downloadDir = $DownloadDir
          logFile = $logFile
          progressUrl = "http://127.0.0.1:$Port/?job=$jobId"
        }
      } else {
        Send-HttpResponse $request.Stream 404 @{ ok = $false; error = "Not found" }
      }
    } catch {
      try {
        Send-HttpResponse ($client.GetStream()) 500 @{ ok = $false; error = $_.Exception.Message }
      } catch {
      }
    } finally {
      $client.Close()
    }
  }
}

if ($SelfTest) {
  Ensure-Dirs
  $ffmpegStatus = Get-FfmpegStatus
  Write-Host "Self test passed: folders are writable."
  Write-Host "ffmpeg: $($ffmpegStatus.message)"
  if ($ffmpegStatus.path) {
    Write-Host "ffmpeg path: $($ffmpegStatus.path)"
  }
  if ($ffmpegStatus.version) {
    Write-Host "ffmpeg version: $($ffmpegStatus.version)"
  }
  if (!$ffmpegStatus.ok) {
    Write-Host "How to fix:"
    foreach ($fix in $ffmpegStatus.fix) {
      Write-Host "- $fix"
    }
  }
  exit 0
}

if ($RunJob) {
  Invoke-BiliFetchJob $JobFile
  exit 0
}

Start-HelperServer
